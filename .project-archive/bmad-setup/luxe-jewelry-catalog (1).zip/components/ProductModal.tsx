import React, { useState, useRef } from 'react';
import { ProductModel, ProductVariation } from '../types';
import { X, Printer, ZoomIn, Info } from 'lucide-react';
import { Button } from './Button';

interface ProductModalProps {
  product: ProductModel | null;
  onClose: () => void;
  userLogo: string;
}

export const ProductModal: React.FC<ProductModalProps> = ({ product, onClose, userLogo }) => {
  const [activeImage, setActiveImage] = useState<string>('');
  const [zoom, setZoom] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  React.useEffect(() => {
    if (product) {
      setActiveImage(product.thumbnail);
      setZoom(false);
    }
  }, [product]);

  if (!product) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleImageMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!zoom || !imgRef.current) return;
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    imgRef.current.style.transformOrigin = `${x}% ${y}%`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-white w-full max-w-6xl max-h-[90vh] overflow-y-auto rounded-lg shadow-2xl relative flex flex-col md:flex-row print:shadow-none print:w-full print:max-w-none print:max-h-none print:fixed print:inset-0 print:z-[100]">
        
        {/* Close Button (Hidden on Print) */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-white/80 rounded-full hover:bg-white transition-colors print:hidden"
        >
          <X size={24} className="text-slate-800" />
        </button>

        {/* --- LEFT: Image Gallery --- */}
        <div className="w-full md:w-1/2 bg-slate-50 p-6 flex flex-col items-center justify-center print:w-1/3 print:bg-white">
            <div 
              className="relative w-full aspect-square max-w-md overflow-hidden cursor-zoom-in rounded-lg shadow-sm print:shadow-none"
              onClick={() => setZoom(!zoom)}
              onMouseMove={handleImageMouseMove}
              onMouseLeave={() => setZoom(false)}
            >
              <img 
                ref={imgRef}
                src={activeImage} 
                alt={product.ref} 
                className={`w-full h-full object-contain transition-transform duration-200 ${zoom ? 'scale-[2.5]' : 'scale-100'}`}
              />
              <div className="absolute bottom-2 right-2 bg-white/70 p-1 rounded text-xs text-slate-500 flex items-center gap-1 pointer-events-none print:hidden">
                <ZoomIn size={14}/> {zoom ? 'Click to out' : 'Click to zoom'}
              </div>
            </div>

            {/* Thumbnails of variations */}
            <div className="flex gap-2 mt-4 overflow-x-auto w-full px-2 py-2 print:hidden">
               {product.variations.map((v, i) => (
                 <button 
                   key={i} 
                   onClick={() => setActiveImage(v.img)}
                   className={`shrink-0 w-16 h-16 border-2 rounded overflow-hidden ${activeImage === v.img ? 'border-gold-500' : 'border-transparent'}`}
                 >
                   <img src={v.img} className="w-full h-full object-cover" alt="" />
                 </button>
               ))}
            </div>
        </div>

        {/* --- RIGHT: Details & Table --- */}
        <div className="w-full md:w-1/2 p-8 flex flex-col print:w-2/3 print:p-0">
          
          {/* Print Header (Only visible when printing) */}
          <div className="hidden print:flex justify-between items-center mb-8 border-b pb-4">
             <img src={userLogo} alt="Logo" className="h-12 w-auto" />
             <div className="text-right">
               <h1 className="text-xl font-bold font-serif">{product.ref}</h1>
               <p className="text-sm text-slate-500">{new Date().toLocaleDateString()}</p>
             </div>
          </div>

          <div className="mb-6">
            <h2 className="text-sm uppercase tracking-widest text-gold-600 mb-1 font-bold">{product.line}</h2>
            <h1 className="text-4xl font-serif text-slate-900 mb-2">{product.category} <span className="text-slate-400 font-light">#{product.ref}</span></h1>
            <p className="text-slate-500 text-sm italic">Découvrez les déclinaisons de ce modèle d'exception.</p>
          </div>

          {/* Action Bar */}
          <div className="flex gap-3 mb-6 print:hidden">
            <Button onClick={handlePrint} variant="secondary" className="flex items-center gap-2">
              <Printer size={16} /> Imprimer Tarifs
            </Button>
          </div>

          {/* Variations Table */}
          <div className="overflow-x-auto flex-1 border border-slate-100 rounded-lg">
            <table className="w-full text-left text-sm">
              <thead className="bg-gold-50 text-gold-800 border-b border-gold-100">
                <tr>
                  <th className="p-3 font-semibold">Label</th>
                  <th className="p-3 font-semibold">Détails Pierre</th>
                  <th className="p-3 font-semibold text-right">Prix</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {product.variations.map((v, idx) => (
                  <tr 
                    key={idx} 
                    className="hover:bg-slate-50 cursor-pointer transition-colors"
                    onClick={() => setActiveImage(v.img)}
                  >
                    <td className="p-3 font-medium text-slate-700">
                      {v.label}
                      <div className="text-xs text-slate-400 font-normal">{v.resolvedType}</div>
                    </td>
                    <td className="p-3 text-slate-600">
                      <span className="inline-block px-2 py-0.5 bg-slate-100 rounded text-xs mr-2">
                        {v.resolvedShape}
                      </span>
                      {v.id_centre}
                    </td>
                    <td className="p-3 text-right font-bold text-slate-900">
                      {v.prix.toLocaleString('fr-FR')} €
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-4 p-3 bg-slate-50 rounded text-xs text-slate-500 flex items-start gap-2 print:hidden">
             <Info size={16} className="shrink-0 mt-0.5" />
             <p>Cliquez sur une ligne pour voir l'image correspondante. Utilisez le bouton "Imprimer" pour générer une fiche produit client.</p>
          </div>

        </div>
      </div>
    </div>
  );
};