import { RawProductItem, ProductModel, StoneShape, StoneType, User, ProductVariation } from '../types';

// --- MOCKED DATABASE TABLES ---

const SHAPES_DB: StoneShape[] = [
  { id: 999, description: 'AUTRE', typ_dim: 0 },
  { id: 1005, description: 'ROND', typ_dim: 0 },
  { id: 1006, description: 'OVALE', typ_dim: 1 },
  { id: 1007, description: 'CARRE', typ_dim: 1 },
  { id: 1008, description: 'PRINCESSE', typ_dim: 1 },
  { id: 1016, description: 'POIRE', typ_dim: 1 },
  { id: 1024, description: 'TROIDA', typ_dim: 1 },
  { id: 1035, description: 'COUSSIN', typ_dim: 1 },
];

const TYPES_DB: StoneType[] = [
  { id: 1003, description: 'DIAMANT' },
  { id: 1004, description: 'RUBIS' },
  { id: 1009, description: 'EMERAUDE' },
  { id: 1012, description: 'SAPHIR' },
  { id: 1006, description: 'OXYDE' },
  // ... add others if needed
];

const RAW_PRODUCTS: RawProductItem[] = [
    {
        "ref": "5802",
        "id_centre": 2996,
        "label": "Poire S.C. 6X4 + Bts 0ct20 GSI",
        "prix": 1190,
        "description": "BAGUE",
        "id_typ_prod": 1,
        "prenom_ligne": "HERITAGE",
        "nom_ligne": "",
        "img_cv": "5802-e-poire-j.jpg",
        "img": "5802-s-poire-r.jpg",
        "id_cv": 641,
        "formes": "1016",
        "gallery": [],
        "id_typ_pier": 1012 // Added manually for demo (Saphir)
    },
    {
        "ref": "5802",
        "id_centre": 2744,
        "label": "Bt Rond 0ct20 + 0ct20 GSI",
        "prix": 1290,
        "description": "BAGUE",
        "id_typ_prod": 1,
        "prenom_ligne": "HERITAGE",
        "nom_ligne": "",
        "img_cv": "5802-e-poire-j.jpg",
        "img": "5802 Diam 38 gris.jpg",
        "id_cv": 641,
        "formes": "1005",
        "gallery": [],
        "id_typ_pier": 1003 // Diamant
    },
    {
        "ref": "5802",
        "id_centre": 2997,
        "label": "Poire Rub. 6x4 + Bts 0ct20 GSI",
        "prix": 1290,
        "description": "BAGUE",
        "id_typ_prod": 1,
        "prenom_ligne": "HERITAGE",
        "nom_ligne": "",
        "img_cv": "5802-e-poire-j.jpg",
        "img": "5802-r-poire-g.jpg",
        "id_cv": 641,
        "formes": "1016",
        "gallery": [],
        "id_typ_pier": 1004 // Rubis
    },
    {
        "ref": "5802",
        "id_centre": 2998,
        "label": "Poire Em. 6x4 + Bts 0ct20 GSI",
        "prix": 1380,
        "description": "BAGUE",
        "id_typ_prod": 1,
        "prenom_ligne": "HERITAGE",
        "nom_ligne": "",
        "img_cv": "5802-e-poire-j.jpg",
        "img": "5802-e-poire-j.jpg",
        "id_cv": 641,
        "formes": "1016",
        "gallery": [],
        "id_typ_pier": 1009 // Emeraude
    },
    {
        "ref": "5802",
        "id_centre": 2285,
        "label": "Ovale S.C. 7x5 + Bts 0ct30 GSI",
        "prix": 1550,
        "description": "BAGUE",
        "id_typ_prod": 1,
        "prenom_ligne": "HERITAGE",
        "nom_ligne": "",
        "img_cv": "5802-e-poire-j.jpg",
        "img": "5802-s-ov-g.jpg",
        "id_cv": 641,
        "formes": "1006",
        "gallery": [
            "5802_ovale_4vues.png"
        ],
        "id_typ_pier": 1012 // Saphir
    },
    {
      "ref": "9000",
      "id_centre": 9999,
      "label": "Alliance Diamant Tour Complet",
      "prix": 2500,
      "description": "ALLIANCE",
      "id_typ_prod": 2,
      "prenom_ligne": "ETERNITY",
      "nom_ligne": "",
      "img_cv": "alliance.jpg",
      "img": "alliance-diam.jpg",
      "id_cv": 642,
      "formes": "1005",
      "gallery": [],
      "id_typ_pier": 1003
  }
];

// --- HELPER FUNCTIONS ---

// Map shape ID to description
const getShapeName = (id: string | number): string => {
  const numId = Number(id);
  return SHAPES_DB.find(s => s.id === numId)?.description || 'AUTRE';
};

// Map type ID to description
const getTypeName = (id: number | undefined): string => {
  if (!id) return '';
  return TYPES_DB.find(t => t.id === id)?.description || '';
};

// Simulate Login
export const loginUser = async (username: string): Promise<User> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // In a real app, you would validate password here.
  // We simulate fetching a specific logo for the user.
  return {
    id: 'u123',
    username: username,
    companyName: "Joaillerie " + username.charAt(0).toUpperCase() + username.slice(1),
    // Using a placeholder logo that looks professional
    logoUrl: `https://ui-avatars.com/api/?name=${username}&background=c18b52&color=fff&size=128&font-size=0.4`
  };
};

// Simulate Fetching Product Catalog
export const fetchCatalog = async (): Promise<{
  products: ProductModel[];
  shapes: StoneShape[];
  types: StoneType[];
}> => {
  await new Promise(resolve => setTimeout(resolve, 500));

  // 1. Process variations to add resolved names
  const processedVariations: ProductVariation[] = RAW_PRODUCTS.map(item => ({
    ...item,
    resolvedShape: getShapeName(item.formes),
    resolvedType: getTypeName(item.id_typ_pier),
    // NOTE: In a real app, replace the filenames with real URLs
    // For demo, we use picsum based on ref to get consistent random images
    img: `https://picsum.photos/seed/${item.ref}${item.id_centre}/500/500`, 
    img_cv: `https://picsum.photos/seed/${item.ref}/500/500`
  }));

  // 2. Group by REF
  const groupedMap = new Map<string, ProductModel>();

  processedVariations.forEach(v => {
    if (!groupedMap.has(v.ref)) {
      groupedMap.set(v.ref, {
        ref: v.ref,
        category: v.description,
        line: v.prenom_ligne,
        thumbnail: v.img, // Use first variation image as main thumbnail
        minPrice: v.prix,
        maxPrice: v.prix,
        variations: [],
        availableShapeIds: [],
        availableTypeIds: []
      });
    }

    const group = groupedMap.get(v.ref)!;
    group.variations.push(v);
    
    // Update Min/Max price for the "From X€" label
    if (v.prix < group.minPrice) group.minPrice = v.prix;
    if (v.prix > group.maxPrice) group.maxPrice = v.prix;

    // Aggregate metadata for filtering
    const shapeId = Number(v.formes);
    if (!group.availableShapeIds.includes(shapeId)) group.availableShapeIds.push(shapeId);
    
    if (v.id_typ_pier && !group.availableTypeIds.includes(v.id_typ_pier)) {
      group.availableTypeIds.push(v.id_typ_pier);
    }
  });

  // 3. Extract USED shapes and types only
  const usedShapeIds = new Set<number>();
  const usedTypeIds = new Set<number>();

  Array.from(groupedMap.values()).forEach(p => {
    p.availableShapeIds.forEach(id => usedShapeIds.add(id));
    p.availableTypeIds.forEach(id => usedTypeIds.add(id));
  });

  const activeShapes = SHAPES_DB.filter(s => usedShapeIds.has(s.id));
  const activeTypes = TYPES_DB.filter(t => usedTypeIds.has(t.id));

  return {
    products: Array.from(groupedMap.values()),
    shapes: activeShapes,
    types: activeTypes
  };
};